const express = require('express');
const router = express.Router();
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

//person CRUD

router.get("/", (_, res) => {
    let readData = fs.readFileSync('./post_data.json');
    let data = JSON.parse(readData);
    res.send(data);
})

router.get("/:id", (req, res) => {
    let readData = fs.readFileSync('./post_data.json');
    let data = JSON.parse(readData);
    let id = req.params.id;
    for (let item of data) {
        if (item['id'] == id) {
            res.send(item);
            return;
        }
    }
    res.send({});
})

router.post("/", (req, res) => {
    let readData = fs.readFileSync('./post_data.json');
    let data = JSON.parse(readData);
    let updatedData = null;
    if (req.body) {
        updatedBody = req.body;
        updatedBody["id"] = uuidv4().toString();
        data.push(updatedBody);
    }
    let sendingData = JSON.stringify(data);
    fs.writeFileSync('./post_data.json', sendingData);
    res.send(updatedData);
})

router.post("/all", (req, res) => {
    let readData = fs.readFileSync('./post_data.json');
    let data = JSON.parse(readData);
    try {
        let requestBody = req.body;
        if ("DELETE" in requestBody) {
            let itemIdSet = new Set(requestBody["DELETE"]);
            data = data.filter((item) => !(itemIdSet.has(item["id"])));
        }
        if ("UPDATE" in requestBody) {
            let updateList = requestBody["UPDATE"];
            let updateObject = {}
            updateList.forEach((item) => {
                updateObject[item["id"]] = item;
            })
            for (let i = 0; i < data.length; i++) {
                if (data[i]["id"] in updateObject) {
                    data[i] = {
                        ...data[i],
                        ...updateObject[data[i]["id"]]
                    }
                }
            }
        }
        if ("CREATE" in requestBody) {
            let createList = requestBody["CREATE"];
            createList.forEach((item) => {
                let newItem = item;
                newItem["id"] = uuidv4().toString();
                data.push(newItem);
            })
        }
        let sendingData = JSON.stringify(data);
        fs.writeFileSync('./post_data.json', sendingData);
        res.send(data);
    } catch (e) {
        console.log('error :>> ', e);
        res.send({});
    }
})

router.put("/:id", (req, res) => {
    let id = req.params.id;
    let readData = fs.readFileSync('./post_data.json');
    let data = JSON.parse(readData);
    let updatedObject = {}
    let updateData = req.body;
    if (updateData) {
        for (let item of data) {
            if (item["id"] == id) {
                item = {
                    ...item,
                    ...updateData
                }
                updatedObject = item;
                break;
            }
        }
    }
    let sendingData = JSON.stringify(data);
    fs.writeFileSync('./post_data.json', sendingData);
    res.send(updatedObject);
})

router.delete("/:id", (req, res) => {
    let id = req.params.id;
    let readData = fs.readFileSync('./post_data.json');
    let data = JSON.parse(readData);
    data = data.filter((item) => item["id"] != id);
    let sendingData = JSON.stringify(data);
    fs.writeFileSync('./post_data.json', sendingData);
    res.send({ resp: true });
})

module.exports = router;