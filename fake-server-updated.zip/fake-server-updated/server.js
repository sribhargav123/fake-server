const express = require('express');
const http = require('http');
const https = require('https');
const fs = require('fs');
const httpPort = 3000;
const httpsPort = 3001;
const personRoute = require('./routes/person')
const trainingRoute = require('./routes/training')
const postRoute = require('./routes/post')
app = express()

var key = fs.readFileSync(__dirname + '/certsFiles/selfsigned.key');
var cert = fs.readFileSync(__dirname + '/certsFiles/selfsigned.crt');

var credentials = {
  key: key,
  cert: cert
};

const cors = require('cors');
app.use(cors())
app.use(express.json());

app.use('/person', personRoute)
app.use('/training', trainingRoute)
app.use('/post', postRoute)

var httpServer = http.createServer(app);
var httpsServer = https.createServer(credentials, app);


httpServer.listen(httpPort, () => {
  console.log("Http server listing on port : " + httpPort)
});

httpsServer.listen(httpsPort, () => {
  console.log("Https server listing on port : " + httpsPort)
});
