## How to run?

- npm install
- node ./server.js


GET: https://localhost:3001/training
GET: https://localhost:3001/training/<ID>
POST: https://localhost:3001/training
PUT: https://localhost:3001/training/<ID>
DELETE: https://localhost:3001/training/<ID>

GET: https://localhost:3001/person
GET: https://localhost:3001/person/<ID>
POST: https://localhost:3001/person
PUT: https://localhost:3001/person/<ID>
DELETE: https://localhost:3001/person/<ID>